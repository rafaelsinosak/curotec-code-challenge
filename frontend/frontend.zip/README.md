# Frontend README

This is a React + TypeScript frontend application for managing “Items”. It uses Axios for API calls, Bootstrap for styling, and React Testing Library + Jest for unit tests.

---

## Table of Contents

- [Frontend README](#frontend-readme)
  - [Table of Contents](#table-of-contents)
  - [Prerequisites](#prerequisites)
  - [Installation](#installation)
  - [Available Scripts](#available-scripts)
  - [Project Structure](#project-structure)
  - [Environment Configuration](#environment-configuration)
  - [Testing](#testing)
  - [Styling](#styling)
  - [Folder Layout](#folder-layout)
  - [Notes](#notes)

---

## Prerequisites

- Node.js (≥ 16.x) and npm or pnpm installed  
- A running backend server at `http://localhost:3001/api` (see backend README)  
- Git (optional, if you plan to clone/pull)

---

## Installation

1. **Clone or download** the repository into your local machine.  
2. Navigate to the frontend folder:

   ```bash
   cd frontend
   ```

3. **Install dependencies** using npm or pnpm:

   ```bash
   # Using npm
   npm install

   # OR using pnpm
   pnpm install
   ```

   > **Note:** If you prefer Yarn, you can run `yarn install` assuming you have Yarn installed.

4. Ensure that the backend is running at `http://localhost:3001/api`. By default, the frontend’s Axios instance points there.

---

## Available Scripts

From the `frontend/` directory, you have access to:

- **`npm start`** or **`pnpm dev`**  
  Starts the development server on [http://localhost:3000](http://localhost:3000).  
  ```bash
  # npm
  npm start

  # pnpm
  pnpm start
  ```

  The page will reload when you make edits.  
  You will also see any lint or type errors in the console.

- **`npm run build`** or **`pnpm build`**  
  Bundles the app for production to the `build/` folder. Files are minified and the build is optimized.

- **`npm test`** or **`pnpm test`**  
  Launches Jest in watch mode, running unit tests for components.  
  Press `a` to run all tests or follow on-screen instructions.

- **`npm run eject`** (only with Create React App)  
  Exposes configuration files. *Note:* This is irreversible.

---

## Project Structure

```
frontend/
├─ node_modules/            # Installed packages (do NOT commit)
├─ public/                  # Static assets and index.html
│  └─ index.html
├─ src/
│  ├─ api/
│  │  ├─ api.ts             # Axios instance pointing to backend
│  │  └─ types.ts           # Shared TypeScript types (Item interface)
│  ├─ components/
│  │  ├─ ItemList.tsx       # Renders list of items
│  │  ├─ ListItem.tsx       # Single item (memoized)
│  │  ├─ NewItemForm.tsx    # Form to create new item
│  │  ├─ ItemList.test.tsx  # Unit tests for ItemList
│  │  └─ NewItemForm.test.tsx # Unit tests for NewItemForm
│  ├─ hooks/
│  │  └─ useFetchItems.ts    # Custom hook for fetching data with loading/error
│  ├─ index.css             # Global CSS (imports Bootstrap CSS)
│  ├─ index.tsx             # React entry point; imports Bootstrap CSS and renders App
│  ├─ App.tsx               # Main application component (uses React.memo)
│  └─ setupTests.ts         # Jest/RTL setup (if needed)
├─ __mocks__/
│  └─ axios.js
├─ .gitignore               # Ignores node_modules, build, etc.
├─ babel.config.js          # Babel config for Jest (presets: env, react, typescript)
├─ jest.config.js           # Jest configuration (transforms, moduleNameMapper)
├─ package.json             # NPM scripts and dependencies
├─ pnpm-lock.yaml           # pnpm lockfile (if using pnpm)
├─ README.md                # This file
└─ tsconfig.json            # TypeScript configuration
```

---

## Environment Configuration

This frontend assumes the backend API is available at:

```
http://localhost:3001/api
```

If your backend is hosted elsewhere, update the `baseURL` in:

```ts
// src/api/api.ts
import axios from "axios";

export const api = axios.create({
  baseURL: "http://localhost:3001/api",
});
```

You can hardcode another URL here, or — for more advanced setups — replace with an environment variable:

```ts
// Example using env var (requires additional setup)
export const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || "http://localhost:3001/api",
});
```

Then add to your `.env`:

```
REACT_APP_API_URL=https://your-production-url.com/api
```

---

## Testing

We use **Jest** + **React Testing Library** for component tests. Key points:

- Mocks **Axios** to avoid real HTTP calls.  
- Tests live in `src/components/*.test.tsx`.  
- Each test file includes:

  ```ts
  // No need to call `jest.mock("axios")` directly;
  // there is an automatic mock in __mocks__/axios.js
  import { api } from "../api/api";
  ```

- Run in watch mode:

  ```bash
  npm test
  # or
  pnpm test
  ```

- You should see `PASS` for both `ItemList.test.tsx` and `NewItemForm.test.tsx`.

> **Tip:** If you ever add new components/hooks, create a matching `*.test.tsx` file to cover loading, success, failure, and empty states.

---

## Styling

We use **Bootstrap (v5)** for styling. The relevant setup is:

1. **Install Bootstrap**:
   ```bash
   pnpm add bootstrap
   # or
   npm install bootstrap
   ```

2. **Import CSS** at the very top of `src/index.tsx`:

   ```ts
   import "bootstrap/dist/css/bootstrap.min.css";
   import React from "react";
   import ReactDOM from "react-dom/client";
   import { App } from "./App";
   ```

3. Use Bootstrap classes directly in JSX:
   - Forms: `className="form-control"`, `className="form-label"`, `className="btn btn-primary"`.
   - Lists: `className="list-group"`, `className="list-group-item"`, etc.
   - Utility classes: `d-flex`, `justify-content-between`, `text-muted`, `mb-3`, etc.

You can also add custom CSS in `src/index.css` or import additional styles as needed.

---

## Folder Layout

Below is a visual summary of major folders/files:

```
frontend/
├─ public/
│  └─ index.html
├─ src/
│  ├─ api/
│  │  ├─ api.ts
│  │  └─ types.ts
│  ├─ components/
│  │  ├─ ListItem.tsx
│  │  ├─ ItemList.tsx
│  │  ├─ NewItemForm.tsx
│  │  ├─ ItemList.test.tsx
│  │  └─ NewItemForm.test.tsx
│  ├─ hooks/
│  │  └─ useFetchItems.ts
│  ├─ index.css
│  ├─ index.tsx
│  ├─ App.tsx
│  └─ setupTests.ts
├─ __mocks__/
│  └─ axios.js
├─ .gitignore
├─ babel.config.js
├─ jest.config.js
├─ package.json
├─ pnpm-lock.yaml
├─ README.md
└─ tsconfig.json
```

---

## Notes

- **TypeScript**: All code is written in TSX/TypeScript. Ensure your IDE/editor recognizes `tsconfig.json`.  
- **React.memo / useMemo**: Components are optimized to prevent unnecessary re-renders.  
- **Testing**: Axios is mocked automatically via `__mocks__/axios.js`. No real network requests occur in tests.  
- **Bootstrap**: All styling relies on Bootstrap classes. If you remove the CSS import, you will lose styling.  
- **API Endpoint**: By default, `api.ts` points to `http://localhost:3001/api`. Update if needed.

---

Happy coding! If you encounter any issues, check console logs for errors, verify that the backend is running, and confirm the correct dependencies are installed.
