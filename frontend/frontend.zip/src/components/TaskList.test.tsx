// src/components/TaskList.test.tsx
import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { TaskList } from "./TaskList";
import { api } from "../api/api";
import { Task } from "../api/types";

jest.mock("../api/api");

describe("<TaskList />", () => {
  const mockedApi = api as jest.Mocked<typeof api>;
  const fakeTasks: Task[] = [
    {
      id: 1,
      title: "T1",
      description: "D1",
      status: "PENDING",
      dueDate: "2025-01-01T00:00:00.000Z",
      createdAt: "2024-01-01T00:00:00.000Z",
    },
  ];

  it("renders a list of tasks", async () => {
    // Mock api.get("/tasks") inside useFetchTasks
    mockedApi.get.mockResolvedValueOnce({ data: fakeTasks });

    const onModified = jest.fn();
    render(<TaskList refresh={0} onModified={onModified} />);
    expect(screen.getByText(/loading/i)).toBeInTheDocument();

    // Wait for the list to appear
    await waitFor(() => {
      expect(screen.getByText("T1")).toBeInTheDocument();
      expect(screen.getByText(/PENDING/i)).toBeInTheDocument();
    });
  });

  it("handles delete click", async () => {
    mockedApi.get.mockResolvedValueOnce({ data: fakeTasks });
    mockedApi.delete.mockResolvedValueOnce({}); // no response body needed here

    const onModified = jest.fn();
    render(<TaskList refresh={0} onModified={onModified} />);
    await waitFor(() => expect(screen.getByText("T1")).toBeInTheDocument());

    const deleteBtn = screen.getByRole("button", { name: /delete/i });
    // Simulate user confirming window.confirm
    jest.spyOn(window, "confirm").mockReturnValueOnce(true);

    fireEvent.click(deleteBtn);
    await waitFor(() => {
      expect(mockedApi.delete).toHaveBeenCalledWith("/tasks/1");
      expect(onModified).toHaveBeenCalled();
    });
  });
});
