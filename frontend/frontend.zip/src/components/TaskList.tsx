// src/components/TaskList.tsx
import React, { useState } from "react";
import { useFetchTasks } from "../hooks/useFetchTasks";
import { Task } from "../api/types";
import { api } from "../api/api";

interface TaskListProps {
  refresh: number;
  onModified: () => void;
}

export const TaskList: React.FC<TaskListProps> = ({ refresh, onModified }) => {
  const { data, loading, error: fetchError } = useFetchTasks(refresh);

  // Keep a map of optimistic statuses keyed by task ID
  const [optimisticStatus, setOptimisticStatus] = useState<Record<number, string>>({});
  const [toggleError, setToggleError] = useState<string | null>(null);

  const handleToggleStatus = async (task: Task) => {
    // Determine new status (simple 3‐state logic here)
    const originalStatus = task.status;
    const newStatus =
      originalStatus === "PENDING" ? "IN_PROGRESS" : originalStatus === "IN_PROGRESS" ? "COMPLETED" : "PENDING";

    // 1. Optimistically update local state
    setOptimisticStatus((prev) => ({ ...prev, [task.id]: newStatus }));

    try {
      // 2. Fire the PUT request
      await api.put<Task>(`/tasks/${task.id}`, {
        // Update all required fields; in a real app, you might only send "status"
        title: task.title,
        description: task.description,
        status: newStatus,
        dueDate: task.dueDate,
      });

      // 3. On success: clear the optimistic marker (so the next fetch will show the true server value)
      setOptimisticStatus((prev) => {
        const copy = { ...prev };
        delete copy[task.id];
        return copy;
      });

      onModified(); // trigger re‐fetch of all tasks
    } catch (err) {
      // 4. On failure: revert state and show an error
      setOptimisticStatus((prev) => {
        const copy = { ...prev };
        delete copy[task.id];
        return copy;
      });
      setToggleError("Failed to toggle status. Please try again.");

      // Auto‐clear error message after 3 seconds
      setTimeout(() => setToggleError(null), 3000);
    }
  };

  if (loading) return <p>Loading...</p>;
  if (fetchError) return <p className="text-danger">{fetchError}</p>;
  if (!data || data.length === 0) return <p>No tasks found.</p>;

  return (
    <>
      {toggleError && <div className="alert alert-danger">{toggleError}</div>}

      <ul className="list-group">
        {data.map((task: Task) => {
          // If we have an optimistic status for this ID, use it; otherwise fall back to server status
          const displayedStatus = optimisticStatus[task.id] ?? task.status;

          return (
            <li
              key={task.id}
              className="list-group-item d-flex justify-content-between align-items-center"
            >
              <div>
                <strong>{task.title}</strong> <br />
                <small className="text-muted">
                  Status: {displayedStatus} | Due:{" "}
                  {new Date(task.dueDate).toLocaleDateString()} <br />
                  Created: {new Date(task.createdAt).toLocaleString()}
                </small>
              </div>

              <div className="btn-group btn-group-sm" role="group">
                <button
                  className="btn btn-outline-primary"
                  onClick={() => handleToggleStatus(task)}
                >
                  {/* Show a different label based on current displayedStatus */}
                  {displayedStatus === "COMPLETED" ? "Mark Pending" : "Toggle Status"}
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    </>
  );
};
