// src/hooks/useDebouncedValue.ts
import { useState, useEffect } from "react";

/**
 * Returns a debounced version of `value` that only updates after `delayMs` of
 * no new changes. For example, if `value` changes rapidly, the returned
 * `debounced` value won’t update until the user stops changing `value` for
 * at least `delayMs` milliseconds.
 */
export function useDebouncedValue<T>(value: T, delayMs: number): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const handle = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(handle);
  }, [value, delayMs]);

  return debounced;
}
